/******************************************************************************
 * Copyright (C) Leap Motion, Inc. 2011-2017.                                 *
 * Leap Motion proprietary and  confidential.                                 *
 *                                                                            *
 * Use subject to the terms of the Leap Motion SDK Agreement available at     *
 * https://developer.leapmotion.com/sdk_agreement, or another agreement       *
 * between Leap Motion and you, your company or other organization.           *
 ******************************************************************************/

Leap Motion Core Assets

These assets go along with our V3 Orion Beta.

Before you begin:
  You first need the Leap Motion V3 Orion Beta installed from:
  https://developer.leapmotion.com/

Questions/Bugs/Feature Requests?
  Please post on https://community.leapmotion.com/c/development

